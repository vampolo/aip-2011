package it.aip.controller.test;

import java.util.ArrayList;
import java.util.List;

import it.aip.models.BioProducer;
import it.aip.models.OrganicProduct;
import it.aip.models.Recipe;
import it.aip.models.RecipeProduct;

import org.slim3.controller.Controller;
import org.slim3.controller.Navigation;
import org.slim3.datastore.Datastore;

public class IndexController extends Controller {

    @Override
    public Navigation run() throws Exception {
        
        /*
        // CODE FOR DATABASE POPULATION
        
        // Creo un produttore
        BioProducer producer1 = new BioProducer();
        producer1.setProducerName("producer1");
        producer1.setInfoAzienda("InfoAzienda1");
        producer1.setProductionMethod("productionMethods1");
 
        // Creo 3 prodotti
        OrganicProduct product1 = new OrganicProduct();
        product1.setProductName("product1");
        product1.setProductCategory("category1");
        product1.setGeneralInfo("generalInfo1");
        product1.setHealthBenefits("healthBenefitsProduct1");
        
        OrganicProduct product2 = new OrganicProduct();
        product2.setProductName("product2");
        product2.setProductCategory("category2");
        product2.setGeneralInfo("generalInfo2");
        product2.setHealthBenefits("healthBenefitsProduct2");
        
        OrganicProduct product3 = new OrganicProduct();
        product3.setProductName("product3");
        product3.setProductCategory("category3");
        product3.setGeneralInfo("generalInfo3");
        product3.setHealthBenefits("healthBenefitsProduct3");
        
        // Creo 3 ricette
        Recipe recipe1 = new Recipe();
        recipe1.setRecipeName("recipe1");
        recipe1.setRecipeType("type1");
        recipe1.setRecipeDescription("recipeDescription1");
        
        Recipe recipe2 = new Recipe();
        recipe2.setRecipeName("recipe2");
        recipe2.setRecipeType("type2");
        recipe2.setRecipeDescription("recipeDescription2");
        
        Recipe recipe3 = new Recipe();
        recipe3.setRecipeName("recipe3");
        recipe3.setRecipeType("type3");
        recipe3.setRecipeDescription("recipeDescription3");
        
        // Linko i prodotti al produttore
        product1.getProducerRef().setModel(producer1);
        product2.getProducerRef().setModel(producer1);
        product3.getProducerRef().setModel(producer1);
        
        // Linko 1 prodotto alla prima ricetta
        RecipeProduct recipeProduct11 = new RecipeProduct();
        recipeProduct11.getRecipeRef().setModel(recipe1);
        recipeProduct11.getProductRef().setModel(product1);
        
        // Linko 2 prodotti alla seconda ricetta
        RecipeProduct recipeProduct21 = new RecipeProduct();
        recipeProduct21.getRecipeRef().setModel(recipe2);
        recipeProduct21.getProductRef().setModel(product1);
        
        RecipeProduct recipeProduct22 = new RecipeProduct();
        recipeProduct22.getRecipeRef().setModel(recipe2);
        recipeProduct22.getProductRef().setModel(product2);
        
        // Linko 3 prodotti alla terza ricetta
        RecipeProduct recipeProduct31 = new RecipeProduct();
        recipeProduct31.getRecipeRef().setModel(recipe3);
        recipeProduct31.getProductRef().setModel(product1);
        
        RecipeProduct recipeProduct32 = new RecipeProduct();
        recipeProduct32.getRecipeRef().setModel(recipe3);
        recipeProduct32.getProductRef().setModel(product2);
        
        RecipeProduct recipeProduct33 = new RecipeProduct();
        recipeProduct33.getRecipeRef().setModel(recipe3);
        recipeProduct33.getProductRef().setModel(product3);
        
        // Salvataggio dati nella Big Table
        Datastore.put(
            producer1, 
            product1, product2, product3, 
            recipe1, recipe2, recipe3, 
            recipeProduct11, recipeProduct21, recipeProduct22, recipeProduct31, recipeProduct32, recipeProduct33);
        
        
        // Creo una lista di prodotti (per vedere se riesco a visualizzarla)
        
        List<OrganicProduct> productsList = new ArrayList<OrganicProduct>();
        productsList.add(product1);
        productsList.add(product2);
        productsList.add(product3);
        requestScope("productsList", productsList);
        */
        
        return forward("index.jsp");
    }
}
